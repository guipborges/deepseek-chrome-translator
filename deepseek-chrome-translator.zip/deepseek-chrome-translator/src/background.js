const PENDING_TEXT_KEY = "deepseekTranslatorPendingText";
const SETTINGS_KEY = "deepseekTranslatorSettings";
const FLASHCARDS_KEY = "deepseekTranslatorFlashcards";
const MIGRATION_FLAG_KEY = "deepseekTranslatorFlashcardsMigrated";
const MAIN_WINDOW_ID_KEY = "deepseekTranslatorMainWindowId";
const SELECTION_HISTORY_KEY = "deepseekTranslatorSelectionHistory";

const DB_NAME = "deepseek-translator-db";
const DB_VERSION = 1;
const FLASHCARDS_STORE = "flashcards";

function setPendingText(text) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [PENDING_TEXT_KEY]: text }, () => resolve());
  });
}

function storageGet(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => resolve(result[key]));
  });
}

function storageSet(key, value) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [key]: value }, () => resolve());
  });
}

function normalizeHistoryText(text) {
  return (text || "").trim().replace(/\s+/g, " ");
}

async function addToSelectionHistory(text) {
  const normalized = normalizeHistoryText(text);
  if (!normalized) {
    return;
  }

  const history = (await storageGet(SELECTION_HISTORY_KEY)) || [];
  const filtered = history.filter((item) => (item || "").toLowerCase() !== normalized.toLowerCase());
  const next = [normalized, ...filtered].slice(0, 20);
  await storageSet(SELECTION_HISTORY_KEY, next);
}

function createMainWindowUrl() {
  return chrome.runtime.getURL("src/popup.html?pinned=1");
}

async function createMainWindow() {
  const settings = (await storageGet(SETTINGS_KEY)) || {};
  const popupWidth = Math.max(420, Math.min(820, Number(settings.popupWidth || 340) + 40));
  const popupHeight = Math.max(560, Math.min(900, Number(settings.popupHeight || 520) + 120));

  const created = await chrome.windows.create({
    url: createMainWindowUrl(),
    type: "popup",
    width: popupWidth,
    height: popupHeight,
    focused: true
  });

  if (created?.id) {
    await storageSet(MAIN_WINDOW_ID_KEY, created.id);
  }

  return created;
}

async function openOrFocusMainWindow() {
  const savedWindowId = await storageGet(MAIN_WINDOW_ID_KEY);

  if (savedWindowId) {
    try {
      const existing = await chrome.windows.get(savedWindowId, { populate: true });
      if (existing?.id) {
        await chrome.windows.update(existing.id, { focused: true });
        return existing;
      }
    } catch (_error) {
      // Window may have been closed; fallback to search/create below.
    }
  }

  const all = await chrome.windows.getAll({ populate: true });
  const targetUrlPrefix = createMainWindowUrl();

  for (const win of all) {
    const hasPopupTab = (win.tabs || []).some((tab) => (tab.url || "").startsWith(targetUrlPrefix));
    if (hasPopupTab && win.id) {
      await storageSet(MAIN_WINDOW_ID_KEY, win.id);
      await chrome.windows.update(win.id, { focused: true });
      return win;
    }
  }

  return createMainWindow();
}

async function focusExistingMainWindowIfOpen() {
  const savedWindowId = await storageGet(MAIN_WINDOW_ID_KEY);

  if (savedWindowId) {
    try {
      const existing = await chrome.windows.get(savedWindowId, { populate: true });
      if (existing?.id) {
        await chrome.windows.update(existing.id, { focused: true });
        return true;
      }
    } catch (_error) {
      // Saved id is stale; continue lookup by URL.
    }
  }

  const all = await chrome.windows.getAll({ populate: true });
  const targetUrlPrefix = createMainWindowUrl();

  for (const win of all) {
    const hasPopupTab = (win.tabs || []).some((tab) => (tab.url || "").startsWith(targetUrlPrefix));
    if (hasPopupTab && win.id) {
      await storageSet(MAIN_WINDOW_ID_KEY, win.id);
      await chrome.windows.update(win.id, { focused: true });
      return true;
    }
  }

  return false;
}

chrome.windows.onRemoved.addListener(async (windowId) => {
  const savedWindowId = await storageGet(MAIN_WINDOW_ID_KEY);
  if (savedWindowId && savedWindowId === windowId) {
    await storageSet(MAIN_WINDOW_ID_KEY, null);
  }
});

chrome.action.onClicked.addListener(() => {
  openOrFocusMainWindow().catch(() => {
    // Ignore click failures silently.
  });
});

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(FLASHCARDS_STORE)) {
        db.createObjectStore(FLASHCARDS_STORE, { keyPath: "id" });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Falha ao abrir IndexedDB."));
  });
}

function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Erro na operacao do IndexedDB."));
  });
}

async function listFlashcardsFromDb() {
  const db = await openDatabase();

  try {
    const tx = db.transaction(FLASHCARDS_STORE, "readonly");
    const store = tx.objectStore(FLASHCARDS_STORE);
    const items = (await requestToPromise(store.getAll())) || [];

    items.sort((a, b) => {
      const aDate = a.createdAt || "";
      const bDate = b.createdAt || "";
      return bDate.localeCompare(aDate);
    });

    return items;
  } finally {
    db.close();
  }
}

async function putFlashcardInDb(entry) {
  const db = await openDatabase();

  try {
    const tx = db.transaction(FLASHCARDS_STORE, "readwrite");
    const store = tx.objectStore(FLASHCARDS_STORE);
    await requestToPromise(store.put(entry));
  } finally {
    db.close();
  }
}

async function removeFlashcardFromDb(id) {
  const db = await openDatabase();

  try {
    const tx = db.transaction(FLASHCARDS_STORE, "readwrite");
    const store = tx.objectStore(FLASHCARDS_STORE);
    await requestToPromise(store.delete(id));
  } finally {
    db.close();
  }
}

async function clearFlashcardsFromDb() {
  const db = await openDatabase();

  try {
    const tx = db.transaction(FLASHCARDS_STORE, "readwrite");
    const store = tx.objectStore(FLASHCARDS_STORE);
    await requestToPromise(store.clear());
  } finally {
    db.close();
  }
}

async function migrateStorageFlashcardsIfNeeded() {
  const migrated = await storageGet(MIGRATION_FLAG_KEY);
  if (migrated) {
    return;
  }

  const legacyList = (await storageGet(FLASHCARDS_KEY)) || [];
  for (const item of legacyList) {
    if (!item?.id) {
      continue;
    }

    await putFlashcardInDb(item);
  }

  await storageSet(MIGRATION_FLAG_KEY, true);
}

function normalizeWord(text) {
  return (text || "").trim().replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
}

function normalizeTerm(text) {
  return (text || "").trim().replace(/\s+/g, " ");
}

function splitTermWords(text) {
  return normalizeTerm(text)
    .split(" ")
    .map((part) => part.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ""))
    .filter(Boolean);
}

function isSingleWord(text) {
  const cleaned = normalizeWord(text);
  if (!cleaned) {
    return false;
  }

  if (/\s/u.test(cleaned)) {
    return false;
  }

  return /[\p{L}\p{N}]/u.test(cleaned);
}

function isPhrasalVerbLike(text) {
  const words = splitTermWords(text);
  if (words.length < 2 || words.length > 3) {
    return false;
  }

  const particles = new Set([
    "up",
    "down",
    "off",
    "on",
    "in",
    "out",
    "away",
    "back",
    "over",
    "through",
    "along",
    "around",
    "about",
    "across",
    "after",
    "apart",
    "with"
  ]);

  const firstWordLooksValid = /^[\p{L}][\p{L}'-]*$/u.test(words[0]);
  if (!firstWordLooksValid) {
    return false;
  }

  return words.slice(1).some((word) => particles.has(word.toLowerCase()));
}

function isAdvancedTerm(text) {
  return isSingleWord(text) || isPhrasalVerbLike(text);
}

async function translateWithDeepSeek(text, overrides = {}) {
  const settings = (await storageGet(SETTINGS_KEY)) || {};
  const apiKey = (settings.apiKey || "").trim();
  const sourceLanguage = (overrides.sourceLanguage || settings.sourceLanguage || "auto").trim();
  const targetLanguage = (overrides.targetLanguage || settings.targetLanguage || "pt-BR").trim();
  const model = (settings.model || "deepseek-chat").trim();

  if (!apiKey) {
    throw new Error("Configure a API key em Configuracoes.");
  }

  const response = await fetch("https://api.deepseek.com/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      temperature: 0,
      messages: [
        {
          role: "system",
          content:
            "You are a translation engine. Translate faithfully and naturally. Return only the translated text."
        },
        {
          role: "user",
          content:
            `Translate the following text from ${sourceLanguage} to ${targetLanguage}. ` +
            "Keep formatting and return only the translation.\n\n" +
            text
        }
      ]
    })
  });

  const data = await response.json();
  if (!response.ok) {
    const details = data?.error?.message || JSON.stringify(data);
    throw new Error(details);
  }

  const translatedText = data?.choices?.[0]?.message?.content?.trim();
  if (!translatedText) {
    throw new Error("Resposta da API sem texto traduzido.");
  }

  return normalizeTranslatedText(translatedText);
}

function normalizeTranslatedText(text) {
  const raw = (text || "").trim();
  if (!raw) {
    return "";
  }

  const lines = raw
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (!lines.length) {
    return raw;
  }

  const firstLine = lines[0].toLowerCase();
  const looksLikePreamble =
    firstLine.startsWith("translating ") ||
    (firstLine.startsWith("translation") && firstLine.includes("from") && firstLine.includes("to"));

  if (looksLikePreamble && lines.length > 1) {
    return lines.slice(1).join("\n").trim();
  }

  return raw;
}

async function saveFlashcard(sourceText, translatedText) {
  await migrateStorageFlashcardsIfNeeded();

  const settings = (await storageGet(SETTINGS_KEY)) || {};
  const configuredSourceLanguage = (settings.sourceLanguage || "auto").trim();
  const targetLanguage = (settings.targetLanguage || "pt-BR").trim();

  const list = await listFlashcardsFromDb();
  const normalizedSource = normalizeTerm(sourceText);
  const normalizedTranslated = (translatedText || "").trim();

  if (!normalizedSource || !normalizedTranslated) {
    throw new Error("Dados invalidos para salvar flashcard.");
  }

  if (!isAdvancedTerm(normalizedSource)) {
    throw new Error("Flashcard aceita apenas palavra unica ou phrasal verb.");
  }

  const detectedLanguage = await detectLanguageSmart(normalizedSource, configuredSourceLanguage);
  const sourceLanguage =
    detectedLanguage && detectedLanguage !== "und" ? detectedLanguage : configuredSourceLanguage;

  const alreadyExists = list.some(
    (item) =>
      (item.sourceText || "").toLowerCase() === normalizedSource.toLowerCase() &&
      (item.sourceLanguage || "") === sourceLanguage &&
      (item.targetLanguage || "") === targetLanguage
  );

  if (alreadyExists) {
    return { alreadyExists: true };
  }

  const entry = {
    id: Date.now().toString(),
    sourceText: normalizedSource,
    translatedText: normalizedTranslated,
    sourceLanguage,
    targetLanguage,
    createdAt: new Date().toISOString()
  };

  await putFlashcardInDb(entry);

  return { alreadyExists: false };
}

async function listFlashcards() {
  await migrateStorageFlashcardsIfNeeded();
  return listFlashcardsFromDb();
}

async function removeFlashcard(id) {
  await migrateStorageFlashcardsIfNeeded();
  await removeFlashcardFromDb(id);
}

async function clearFlashcards() {
  await migrateStorageFlashcardsIfNeeded();
  await clearFlashcardsFromDb();
}

function mapLanguageToYouGlish(language) {
  const code = (language || "").toLowerCase();

  if (code.startsWith("pt")) {
    return "portuguese";
  }

  if (code.startsWith("es")) {
    return "spanish";
  }

  if (code.startsWith("fr")) {
    return "french";
  }

  if (code.startsWith("de")) {
    return "german";
  }

  if (code.startsWith("it")) {
    return "italian";
  }

  if (code.startsWith("zh")) {
    return "chinese";
  }

  return "english";
}

function detectLanguageWithChrome(text) {
  return new Promise((resolve) => {
    if (!chrome?.i18n?.detectLanguage || !text) {
      resolve(null);
      return;
    }

    chrome.i18n.detectLanguage(text, (result) => {
      if (chrome.runtime.lastError || !result?.languages?.length) {
        resolve(null);
        return;
      }

      const best = result.languages[0] || null;
      resolve(
        best
          ? {
              language: best.language || null,
              percentage: typeof best.percentage === "number" ? best.percentage : 0,
              isReliable: !!result.isReliable
            }
          : null
      );
    });
  });
}

async function detectLanguageWithDeepSeek(text) {
  const settings = (await storageGet(SETTINGS_KEY)) || {};
  const apiKey = (settings.apiKey || "").trim();
  const model = (settings.model || "deepseek-chat").trim();

  if (!apiKey || !text) {
    return null;
  }

  try {
    const response = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        temperature: 0,
        max_tokens: 12,
        messages: [
          {
            role: "system",
            content:
              "Identify the language of the provided text. Return only the ISO 639-1 code in lowercase, like en, de, fr, es, pt, it, nl, ru, zh. Return und if unknown."
          },
          {
            role: "user",
            content: text
          }
        ]
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return null;
    }

    const raw = (data?.choices?.[0]?.message?.content || "").trim().toLowerCase();
    const match = raw.match(/^[a-z]{2,3}(?:-[a-z]{2})?/);
    if (!match) {
      return null;
    }

    const code = match[0];
    if (code === "und") {
      return null;
    }

    return code;
  } catch (_error) {
    return null;
  }
}

async function detectLanguageSmart(text, fallbackLanguage) {
  const normalizedFallback = (fallbackLanguage || "").trim().toLowerCase();
  if (normalizedFallback && normalizedFallback !== "auto") {
    return fallbackLanguage;
  }

  const chromeDetection = await detectLanguageWithChrome(text);
  const chromeCode = chromeDetection?.language || null;
  const chromeConfidence = chromeDetection?.percentage || 0;
  const normalized = normalizeWord(text);
  const isShortWord = normalized.length > 0 && normalized.length <= 6;

  if (chromeCode && chromeCode !== "und") {
    const lowConfidence = chromeConfidence < 70 || (isShortWord && chromeConfidence < 92);

    if (!lowConfidence) {
      return chromeCode;
    }
  }

  const deepSeekCode = await detectLanguageWithDeepSeek(text);
  if (deepSeekCode) {
    return deepSeekCode;
  }

  if (chromeCode && chromeCode !== "und") {
    return chromeCode;
  }

  return fallbackLanguage || null;
}

async function detectYouGlishLanguage(text, fallbackLanguage) {
  const detected = await detectLanguageSmart(text, fallbackLanguage);
  if (detected && detected !== "und") {
    return mapLanguageToYouGlish(detected);
  }

  return mapLanguageToYouGlish(fallbackLanguage);
}

async function openYouGlishWindow(text, languageHint) {
  const cleanText = normalizeTerm(text);
  if (!cleanText) {
    throw new Error("Texto invalido para YouGlish.");
  }

  if (!isAdvancedTerm(cleanText)) {
    throw new Error("YouGlish aceita apenas palavra unica ou phrasal verb.");
  }

  const safeLang = await detectYouGlishLanguage(cleanText, languageHint);
  const variant = safeLang === "english" ? "/us" : "";
  const url =
    `https://youglish.com/pronounce/${encodeURIComponent(cleanText)}/` +
    `${encodeURIComponent(safeLang)}${variant}`;

  return chrome.windows.create({
    url,
    type: "popup",
    width: 560,
    height: 520
  });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "DOUBLE_CLICK_TEXT") {
    const text = (message.text || "").trim();

    if (!text) {
      sendResponse({ ok: false });
      return;
    }

    Promise.all([setPendingText(text), addToSelectionHistory(text)])
      .then(async () => {
        const settings = (await storageGet(SETTINGS_KEY)) || {};
        if (settings.openMainWindowOnDoubleClick) {
          await openOrFocusMainWindow();
        } else {
          await focusExistingMainWindowIfOpen();
        }

        sendResponse({ ok: true });
      })
      .catch(() => sendResponse({ ok: false }));

    return true;
  }

  if (message?.type === "OPEN_MAIN_WINDOW") {
    openOrFocusMainWindow()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message || "Falha ao abrir janela principal." }));

    return true;
  }

  if (message?.type === "TRANSLATE_TEXT") {
    const text = (message.text || "").trim();
    const sourceLanguage = (message.sourceLanguage || "").trim();
    const targetLanguage = (message.targetLanguage || "").trim();

    if (!text) {
      sendResponse({ ok: false, error: "Nenhum texto para traduzir." });
      return;
    }

    translateWithDeepSeek(text, {
      sourceLanguage,
      targetLanguage
    })
      .then((translatedText) => {
        sendResponse({ ok: true, translatedText });
      })
      .catch((error) => {
        sendResponse({ ok: false, error: error.message || "Falha na traducao." });
      });

    return true;
  }

  if (message?.type === "SAVE_FLASHCARD") {
    const sourceText = (message.sourceText || "").trim();
    const translatedText = (message.translatedText || "").trim();

    saveFlashcard(sourceText, translatedText)
      .then((result) => {
        sendResponse({ ok: true, alreadyExists: result.alreadyExists });
      })
      .catch((error) => {
        sendResponse({ ok: false, error: error.message || "Falha ao salvar flashcard." });
      });

    return true;
  }

  if (message?.type === "LIST_FLASHCARDS") {
    listFlashcards()
      .then((cards) => sendResponse({ ok: true, cards }))
      .catch((error) => sendResponse({ ok: false, error: error.message || "Falha ao listar flashcards." }));

    return true;
  }

  if (message?.type === "REMOVE_FLASHCARD") {
    const id = (message.id || "").trim();
    if (!id) {
      sendResponse({ ok: false, error: "ID invalido." });
      return;
    }

    removeFlashcard(id)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message || "Falha ao remover flashcard." }));

    return true;
  }

  if (message?.type === "CLEAR_FLASHCARDS") {
    clearFlashcards()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message || "Falha ao limpar flashcards." }));

    return true;
  }

  if (message?.type === "GET_SETTINGS") {
    storageGet(SETTINGS_KEY)
      .then((settings) => sendResponse({ ok: true, settings: settings || {} }))
      .catch((error) => sendResponse({ ok: false, error: error.message || "Falha ao ler configuracoes." }));

    return true;
  }

  if (message?.type === "OPEN_YOUGLISH") {
    const text = (message.text || "").trim();
    const language = (message.language || "").trim();

    openYouGlishWindow(text, language)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message || "Falha ao abrir YouGlish." }));

    return true;
  }

  return;
});
